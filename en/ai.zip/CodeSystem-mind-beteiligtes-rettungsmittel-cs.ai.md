# MIND Beteiligtes Rettungsmittel - DE EMS (R4) v0.1.0

## CodeSystem: MIND Beteiligtes Rettungsmittel 

This Code system is referenced in the definition of the following value sets:

* [MIND Beteiligtes Rettungsmittel ValueSet](ValueSet-mind-beteiligtes-rettungsmittel-vs.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mind-beteiligtes-rettungsmittel-cs",
  "url" : "https://till-ko.github.io/de-ems/CodeSystem/mind-beteiligtes-rettungsmittel-cs",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.25.169126619167380341660016816424527320624.16.6"
  }],
  "version" : "0.1.0",
  "name" : "MindBeteiligtesRettungsmittelCS",
  "title" : "MIND Beteiligtes Rettungsmittel",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-10-30T08:50:03+00:00",
  "publisher" : "Till Koch",
  "contact" : [{
    "name" : "Till Koch",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/till-ko"
    }]
  }],
  "description" : "Typen der am Einsatz beteiligten Rettungsmittel gemäß MIND 7.1.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 22,
  "concept" : [{
    "code" : "01",
    "display" : "NEF"
  },
  {
    "code" : "02",
    "display" : "RTW"
  },
  {
    "code" : "03",
    "display" : "KTW"
  },
  {
    "code" : "04",
    "display" : "NAW"
  },
  {
    "code" : "05",
    "display" : "RTH"
  },
  {
    "code" : "06",
    "display" : "ITH"
  },
  {
    "code" : "07",
    "display" : "ITW"
  },
  {
    "code" : "08",
    "display" : "Langstreckenflugzeug"
  },
  {
    "code" : "09",
    "display" : "Ambulanzflugzeug"
  },
  {
    "code" : "10",
    "display" : "First Responder"
  },
  {
    "code" : "11",
    "display" : "Bergrettung"
  },
  {
    "code" : "12",
    "display" : "Wasserrettung"
  },
  {
    "code" : "13",
    "display" : "Selbstfahrender NA"
  },
  {
    "code" : "14",
    "display" : "Telenotarzt"
  },
  {
    "code" : "15",
    "display" : "Single Responder (Gemeinde-NotSan, REF, AEF, ...)"
  },
  {
    "code" : "16",
    "display" : "LNA"
  },
  {
    "code" : "17",
    "display" : "OrgL"
  },
  {
    "code" : "18",
    "display" : "N-KTW"
  },
  {
    "code" : "19",
    "display" : "MIC"
  },
  {
    "code" : "20",
    "display" : "S-RTW (Schwerlast)"
  },
  {
    "code" : "21",
    "display" : "Ersthelfer-App"
  },
  {
    "code" : "98",
    "display" : "Sonstige"
  }]
}

```
